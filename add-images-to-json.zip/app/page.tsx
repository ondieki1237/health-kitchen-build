"use client"

import  from "../scripts/generate-blobs"

export default function SyntheticV0PageForDeployment() {
  return < />
}